
        const URL = "https://teachablemachine.withgoogle.com/models/UydG11DC4/";
        let model, webcam, labelContainer, maxPredictions;

        async function init() {
            document.querySelector('.loading-overlay').style.display = 'flex';
            
            try {
                const modelURL = URL + "model.json";
                const metadataURL = URL + "metadata.json";

                model = await tmImage.load(modelURL, metadataURL);
                maxPredictions = model.getTotalClasses();

                const flip = true;
                webcam = new tmImage.Webcam(400, 400, flip);
                await webcam.setup();
                await webcam.play();
                window.requestAnimationFrame(loop);

                document.getElementById("webcam-container").appendChild(webcam.canvas);
                labelContainer = document.getElementById("label-container");
                labelContainer.innerHTML = '';
                
                for (let i = 0; i < maxPredictions; i++) {
    const predDiv = document.createElement("div");
    predDiv.className = 'prediction-item animate__animated animate__fadeInRight';
    predDiv.style.animationDelay = `${i * 0.1}s`;
    predDiv.innerHTML = `
        <span class="prediction-label"></span>
        <div class="prediction-bar-container">
            <div class="prediction-bar" style="width: 0%"></div>
        </div>
    `;
    labelContainer.appendChild(predDiv);
}

                document.querySelector('.start-button').style.display = 'none';
            } catch (error) {
                console.error('Error:', error);
                alert('Error al iniciar la cámara. Por favor, verifica los permisos.');
            } finally {
                document.querySelector('.loading-overlay').style.display = 'none';
            }
        }

        async function loop() {
            webcam.update();
            await predict();
            window.requestAnimationFrame(loop);
        }

        async function predict() {
            const prediction = await model.predict(webcam.canvas);
            for (let i = 0; i < maxPredictions; i++) {
                const probability = prediction[i].probability.toFixed(2);
                const percentage = (probability * 100).toFixed(0);
                const predictionItem = labelContainer.childNodes[i];
                predictionItem.querySelector('.prediction-label').textContent = 
                    `${prediction[i].className}: ${percentage}%`;
                predictionItem.querySelector('.prediction-bar').style.width = 
                    `${percentage}%`;
            }
        }
    